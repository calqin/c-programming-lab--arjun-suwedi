#include<stdio.h>
#include<math.h>
int main()
{
    int a,b;
    scanf("%d",&a);
    b = sqrt(a);
    printf("%d",b);
    return 0;
}
