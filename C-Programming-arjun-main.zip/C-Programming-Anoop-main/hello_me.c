#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    char a[100];
    scanf("%s", a);
    printf("Welcome %s",a);
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}
