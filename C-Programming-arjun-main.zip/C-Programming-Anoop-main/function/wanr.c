#include <stdio.h>
void area(int,int);
int main(int argc, char const *argv[])
{
    printf("Enter length and breadth of rectangle\n");
    
    return 0;
}
