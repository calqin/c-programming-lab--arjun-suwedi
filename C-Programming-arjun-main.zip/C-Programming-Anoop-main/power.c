#include <stdio.h>
# include <math.h>
int main(int argc, char const *argv[])
{
    int a,b,c;
    scanf("%d%d",&a,&b);
    c = pow(a,b);
    printf("%d",c);
    return 0;
}
