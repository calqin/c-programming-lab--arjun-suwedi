#include<stdio.h>

int main()
{
    printf("Hello world\n");
    // for integer type
    /*
    int a,b;
    printf("Enter a number\n");
    scanf("%d",&a);
    printf("Enter a number\n");
    scanf("%d",&b);
    printf("%d\n",a+b);
    printf("%d\n",a-b);
    printf("%d\n",a*b);
    printf("%d\n",a/b); 
    printf("%d\n",a%b); 
    */
    // for float type
    /*
    float a,b;
    printf("Enter a number\n");
    scanf("%f",&a);
    printf("Enter a number\n");
    scanf("%f",&b);
    printf("%f\n",a+b);
    printf("%f\n",a-b);
    printf("%f\n",a*b);
    printf("%f\n",a/b); 
    */
    // for char type
    char a;
    printf("Enter a word\n");
    scanf("%c",&a);
    printf("Your Word is\n");
    printf(a);
    return 0;

}
