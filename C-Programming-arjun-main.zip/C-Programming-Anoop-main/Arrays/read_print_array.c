#include<stdio.h>
int main(int argc, char const *argv[])
{
    int a[] = {1,2,3,5,7,9,0};
    for(int i=0;i<=6;i++){
        printf("%d %d",i,a[i]);
        printf("\n");
    }
    return 0;
}
