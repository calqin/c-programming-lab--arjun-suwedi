#include <stdio.h>
#include <math.h>
int main(int argc, char const *argv[])
{
    int a,b;
    scanf("%d",&a);
    b = log10(a)+1;
    printf("%d",b);
    return 0;
}
