#include <stdio.h>
#include <math.h>
int main(int argc, char const *argv[])
{
    int b,h,a;
    scanf("%d%d",&b,&h);
    a = ((0.5)*b*h);
    printf("%d",a);
    return 0;
}
