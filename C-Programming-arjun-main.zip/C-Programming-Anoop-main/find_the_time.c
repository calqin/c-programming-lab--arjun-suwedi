#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    float r,t;
    scanf("%f",&r);
    t = (1/r);
    printf("%.2f",t*100);
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}
