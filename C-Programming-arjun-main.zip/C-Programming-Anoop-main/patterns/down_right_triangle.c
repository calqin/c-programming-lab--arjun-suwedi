#include<stdio.h>
int main(int argc, char const *argv[])
{
    int n,i,j;
    scanf("%d",&n);
    for (i=n;i>=1;i--){
        for (j=i;j>=1;j--){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}