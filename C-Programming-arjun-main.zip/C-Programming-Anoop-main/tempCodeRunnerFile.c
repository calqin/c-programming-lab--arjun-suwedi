("%d\n",c);
        d = d+