//# include <stdio.h>
//int main(int argc, char const *argv[])
//{
// //     // printf("%X",125);
// //     // int i=5;
// //     // printf("%d %d %d ",++i,++i,++i);
// //     // printf("%d",sizeof('\n'));
    //char p=37;
    //printf("%*d %c",p,p);
    // printf("c:\\tc\\bin\'");
    //return 0;
//}

// // #include <stdio.h>
// // int main()
// // {
// // int i,j;
// // for(j=1;j<=10;j++)
// // {
// // for(i=1;i<=10;i++)
// // {
// // if(j<10)
// // goto there;
// // }
// // printf("I am out of home\n");
// // printf("I am out of city\n");
// // printf("I am out of india\n");
// // }
// // there:
// // printf(" I love india\n");

// // return 0;
// // }
// // #include<stdio.h>
// // main()
// // {
// // int expr=2,j=1;
// // switch(expr)
// // {
// // case j:
// // printf("This is case 1");
// // case 2:
// // printf("This is case 2");
// // default:
// // printf("This is default case");
// // }
// // }
// #include<stdio.h>
// main()
// {
// int expr=1;
// switch(expr)
// {
// case 1:printf("One\n");
// case 2:printf("Two\n");
// default:printf("Three\n");
// }
// }
// #include<stdio.h>
// int main(int argc, char const *argv[])
// {
//     printf("%6.3f\n %06.3f\n %09.3f\n %9.3f\n %6.0f\n %6.0f",45.6,45.6,45.6,45.6,45.3,45.6);
//     return 0;
// }
