#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main() {
    int a,b,c,d,e;
    scanf("%d&%d&%d&%d&%d",&a,&b,&c,&d,&e);
    printf("%c%c%c%c%c",a,b,c,d,e);
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */    
    return 0;
}
